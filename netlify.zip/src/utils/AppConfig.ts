export const AppConfig = {
  site_name: 'React landing page',
  title: 'React landing page template 2021',
  description: 'Production ready plug n play landing page!',
  locale: 'en',
};
