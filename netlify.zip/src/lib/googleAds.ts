export const GA_ADS_ID = process.env.NEXT_PUBLIC_GOOGLE_ADS_ID;
