import '../styles/main.css';

const MyApp = ({ Component, pageProps }: any) => (
  <Component {...pageProps} />
);

export default MyApp;
